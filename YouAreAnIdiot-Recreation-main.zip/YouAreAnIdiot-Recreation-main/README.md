# YouAreAnIdiot-Recreation
Recreation of famous "you are an idiot virus" aka offiz

Live demo [here](https://ngn13.github.io/youareanidiot/index.html)

(lol crashed my computer while testing)

NOTE: I am not responsable with the any damage or whatever.
